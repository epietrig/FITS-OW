#!/bin/sh
java -Xmx1024M -Xms512M -jar target/fits-ow-0.1.jar "$@"
