package fr.inria.ilda.fitsow.cursors;

public interface CursorDwellListener {

	void cursorDwelled(CursorDwellEvent event);
	
}
