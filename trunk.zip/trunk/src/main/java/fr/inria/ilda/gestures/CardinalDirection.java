package fr.inria.ilda.gestures;

/**
 * Created by appert on 08/03/15.
 */
public enum CardinalDirection {
    NORTH,
    EAST,
    SOUTH,
    WEST,
    UNKNOWN
}
